// Basic smoke test for Open The Path.

import 'package:flutter_test/flutter_test.dart';

import 'package:open_the_path/main.dart';

void main() {
  testWidgets('App boots and shows the title', (WidgetTester tester) async {
    await tester.pumpWidget(const OpenThePathApp());
    await tester.pump();
    expect(find.text('Open The Path'), findsWidgets);
  });

  test('Title is non-empty', () {
    const title = 'Open The Path';
    expect(title, isNotEmpty);
  });
}
