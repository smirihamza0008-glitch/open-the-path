# Open The Path

A minimal Flutter game built as a starter project. A cube sits on a grid and you can:
- **Tap** anywhere on the screen to teleport the cube.
- **Arrow keys** to step the cube 20px in any direction.
- **Space** to reset position and score.
- The cube rotates continuously, and a live **Score** counter ticks with every step.

## Project layout

```
open_the_path/
├── android/             # Android Gradle project (Kotlin + Flutter Gradle plugin)
├── ios/                 # iOS Xcode project (Swift + Flutter)
├── lib/
│   └── main.dart        # Game entry point
├── test/
│   └── widget_test.dart # Smoke test
├── codemagic.yaml       # Codemagic CI configuration
├── analysis_options.yaml
├── pubspec.yaml
└── README.md
```

## Run locally

```bash
flutter pub get
flutter run            # auto-picks an attached device / emulator
```

## Build artifacts

| Platform | Command                          | Output                                  |
|----------|----------------------------------|-----------------------------------------|
| Android  | `flutter build apk --release`    | `build/app/outputs/flutter-apk/*.apk`   |
| iOS      | `flutter build ipa --release`    | `build/ios/ipa/*.ipa`                   |

## Codemagic

Push to a Git host connected to Codemagic and the `default-workflow` (Android) and `ios-workflow` (iOS) defined in `codemagic.yaml` will:
1. Install Flutter stable
2. `flutter pub get`
3. `flutter test`
4. Build & publish the artifact

No manual signing config is required for the Android debug-signing fallback defined in `android/app/build.gradle` — replace it with your own keystore before publishing to the Play Store.
