package com.example.open_the_path

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
