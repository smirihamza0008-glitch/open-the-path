import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const OpenThePathApp());
}

class OpenThePathApp extends StatelessWidget {
  const OpenThePathApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Open The Path',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const GameScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen>
    with SingleTickerProviderStateMixin {
  static const double _cubeSize = 60.0;
  static const double _step = 20.0;

  Offset _position = const Offset(150, 250);
  late final AnimationController _autoController;
  double _angle = 0.0;
  int _score = 0;

  @override
  void initState() {
    super.initState();
    _autoController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
    _autoController.addListener(_onAutoTick);
  }

  void _onAutoTick() {
    setState(() {
      _angle += 0.05;
    });
  }

  @override
  void dispose() {
    _autoController.removeListener(_onAutoTick);
    _autoController.dispose();
    super.dispose();
  }

  void _move(double dx, double dy) {
    setState(() {
      final size = MediaQuery.of(context).size;
      _position = Offset(
        (_position.dx + dx).clamp(0.0, size.width - _cubeSize),
        (_position.dy + dy).clamp(0.0, size.height - _cubeSize - 80),
      );
      _score += 1;
    });
  }

  KeyEventResult _onKey(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent) return KeyEventResult.ignored;
    if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
      _move(_step, 0);
      return KeyEventResult.handled;
    } else if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
      _move(-_step, 0);
      return KeyEventResult.handled;
    } else if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
      _move(0, -_step);
      return KeyEventResult.handled;
    } else if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
      _move(0, _step);
      return KeyEventResult.handled;
    } else if (event.logicalKey == LogicalKeyboardKey.space) {
      setState(() {
        _position = const Offset(150, 250);
        _score = 0;
        _angle = 0;
      });
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF101422),
      appBar: AppBar(
        title: const Text('Open The Path'),
        backgroundColor: Colors.indigo,
        centerTitle: true,
      ),
      body: Focus(
        autofocus: true,
        onKeyEvent: _onKey,
        child: GestureDetector(
          onTapDown: (details) {
            setState(() {
              _position = details.localPosition - const Offset(30, 30);
            });
          },
          child: Stack(
            children: [
              CustomPaint(
                size: Size.infinite,
                painter: GridPainter(),
              ),
              AnimatedPositioned(
                duration: const Duration(milliseconds: 120),
                curve: Curves.easeOut,
                left: _position.dx,
                top: _position.dy,
                child: Transform.rotate(
                  angle: _angle,
                  child: Container(
                    width: _cubeSize,
                    height: _cubeSize,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Colors.amber, Colors.deepOrange],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black54,
                          blurRadius: 8,
                          offset: Offset(2, 2),
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Icon(
                        Icons.view_in_ar,
                        color: Colors.white,
                        size: 36,
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                left: 16,
                top: 16,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    'Score: $_score',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const Positioned(
                bottom: 12,
                left: 0,
                right: 0,
                child: Center(
                  child: Text(
                    'Tap to move • Arrow keys to step • Space to reset',
                    style: TextStyle(color: Colors.white60, fontSize: 13),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.05)
      ..strokeWidth = 1;
    const step = 40.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
